import java.io.*;
import java.util.Vector;
import javax.bluetooth.*;
import javax.microedition.io.*;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;

public class BTChat extends MIDlet implements CommandListener, Runnable, DiscoveryListener {
    private static final UUID CHAT_UUID = new UUID("F0E0D0C0B0A000908070605040302099", false);
    private static final int MAX_LINES = 40;

    private Display display;
    private Form logForm;
    private List menu;
    private List devList;
    private TextBox inputBox;

    private Command cmdExit = new Command("Exit", Command.EXIT, 1);
    private Command cmdBack = new Command("Back", Command.BACK, 1);
    private Command cmdSend = new Command("Send", Command.SCREEN, 1);
    private Command cmdOk = new Command("OK", Command.OK, 1);
    private Command cmdCancel = new Command("Cancel", Command.CANCEL, 2);

    private StreamConnection conn;
    private StreamConnectionNotifier notifier;
    private DataInputStream in;
    private DataOutputStream out;
    private volatile boolean running;

    private Vector devices = new Vector();
    private Vector records = new Vector();
    private DiscoveryAgent agent;
    private int[] searchIDs;
    private int action;

    public BTChat() { display = Display.getDisplay(this); }

    protected void startApp() {
        if (menu == null) {
            menu = new List("BT Chat", Choice.IMPLICIT);
            menu.append("Host (wait)", null);
            menu.append("Join (search)", null);
            menu.addCommand(cmdExit);
            menu.setCommandListener(this);
            display.setCurrent(menu);
        }
    }

    protected void pauseApp() {}
    protected void destroyApp(boolean u) { closeAll(); }

    public void commandAction(Command c, Displayable d) {
        if (c == cmdExit) { closeAll(); notifyDestroyed(); return; }
        if (c == cmdBack) { closeAll(); display.setCurrent(menu); return; }
        if (d == menu && c == List.SELECT_COMMAND) {
            if (menu.getSelectedIndex() == 0) startHost(); else startClient();
            return;
        }
        if (d == devList && c == List.SELECT_COMMAND) { startServiceSearch(devList.getSelectedIndex()); return; }
        if (d == devList && c == cmdCancel) { try { if (agent != null) agent.cancelInquiry(this); } catch (Exception e) {} display.setCurrent(menu); return; }
        if (d == logForm && c == cmdSend) {
            inputBox = new TextBox("Message", "", 200, TextField.ANY);
            inputBox.addCommand(cmdOk); inputBox.addCommand(cmdCancel);
            inputBox.setCommandListener(this); display.setCurrent(inputBox); return;
        }
        if (d == inputBox && c == cmdOk) {
            String msg = inputBox.getString(); display.setCurrent(logForm);
            if (msg != null && msg.length() > 0) sendMsg(msg); return;
        }
        if (d == inputBox && c == cmdCancel) { display.setCurrent(logForm); return; }
    }

    private void showLog(String title) {
        logForm = new Form(title);
        logForm.addCommand(cmdSend); logForm.addCommand(cmdBack);
        logForm.setCommandListener(this); display.setCurrent(logForm);
    }

    private void log(final String s) {
        display.callSerially(new Runnable() { public void run() {
            if (logForm == null) return;
            if (logForm.size() >= MAX_LINES) logForm.delete(0);
            logForm.append(s + "\n");
        }});
    }

    private void startHost() { showLog("Hosting"); log("Starting..."); closeConn(); action = 1; new Thread(this).start(); }
    private void startClient() {
        closeConn(); devices.removeAllElements(); records.removeAllElements();
        devList = new List("Searching...", Choice.IMPLICIT);
        devList.addCommand(cmdCancel); devList.setCommandListener(this);
        display.setCurrent(devList); action = 2; new Thread(this).start();
    }

    public void run() {
        try {
            if (action == 1) runHost();
            else if (action == 2) runDiscover();
            else if (action == 3) runServiceSearch();
        } catch (Exception e) { log("Err: " + e); }
    }

    private void runHost() throws Exception {
        LocalDevice ld = LocalDevice.getLocalDevice();
        try { ld.setDiscoverable(DiscoveryAgent.GIAC); } catch (Exception e) {}
        String url = "btspp://localhost:" + CHAT_UUID.toString() + ";name=BTChat;authorize=false";
        notifier = (StreamConnectionNotifier) Connector.open(url);
        log("Waiting for client...");
        conn = notifier.acceptAndOpen();
        try { notifier.close(); } catch (Exception e) {} notifier = null;
        openStreams(); log("Connected."); runReader();
    }

    private void runDiscover() throws Exception {
        agent = LocalDevice.getLocalDevice().getDiscoveryAgent();
        agent.startInquiry(DiscoveryAgent.GIAC, this);
    }

    private void runServiceSearch() throws Exception {
        UUID[] uuids = new UUID[] { CHAT_UUID };
        int[] attrs = new int[] { 0x0100 };
        searchIDs = new int[devices.size()];
        boolean any = false;
        for (int i = 0; i < devices.size(); i++) {
            try { searchIDs[i] = agent.searchServices(attrs, uuids, (RemoteDevice) devices.elementAt(i), this); any = true; }
            catch (Exception e) { searchIDs[i] = -1; }
        }
        if (!any) failToMenu("No service search");
    }

    public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {
        if (devices.indexOf(btDevice) == -1) devices.addElement(btDevice);
    }

    public void inquiryCompleted(int discType) {
        display.callSerially(new Runnable() { public void run() {
            if (devices.size() == 0) { failToMenu("No devices"); return; }
            devList = new List("Select device", Choice.IMPLICIT);
            for (int i = 0; i < devices.size(); i++) {
                String name;
                try { name = ((RemoteDevice)devices.elementAt(i)).getFriendlyName(false); }
                catch (Exception e) { name = ((RemoteDevice)devices.elementAt(i)).getBluetoothAddress(); }
                if (name == null || name.length() == 0) name = ((RemoteDevice)devices.elementAt(i)).getBluetoothAddress();
                devList.append(name, null);
            }
            devList.addCommand(cmdCancel); devList.setCommandListener(BTChat.this);
            display.setCurrent(devList);
        }});
    }

    private void startServiceSearch(int idx) {
        if (idx < 0 || idx >= devices.size()) return;
        RemoteDevice rd = (RemoteDevice) devices.elementAt(idx);
        devices.removeAllElements(); devices.addElement(rd); records.removeAllElements();
        showLog("Connecting"); log("Searching service..."); action = 3; new Thread(this).start();
    }

    public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {
        for (int i = 0; i < servRecord.length; i++) records.addElement(servRecord[i]);
    }

    public void serviceSearchCompleted(int transID, int respCode) {
        synchronized (this) {
            if (searchIDs == null) return;
            boolean done = true;
            for (int i = 0; i < searchIDs.length; i++) {
                if (searchIDs[i] == transID) searchIDs[i] = -1;
                if (searchIDs[i] != -1) done = false;
            }
            if (!done) return;
        }
        display.callSerially(new Runnable() { public void run() {
            if (records.size() == 0) { failToMenu("No chat service"); return; }
            connectToService((ServiceRecord) records.elementAt(0));
        }});
    }

    private void connectToService(final ServiceRecord sr) {
        new Thread(new Runnable() { public void run() {
            try {
                String url = sr.getConnectionURL(ServiceRecord.NOAUTHENTICATE_NOENCRYPT, false);
                conn = (StreamConnection) Connector.open(url);
                openStreams(); log("Connected."); runReader();
            } catch (Exception e) { log("Connect err: " + e); }
        }}).start();
    }

    private void openStreams() throws IOException {
        in = conn.openDataInputStream();
        out = conn.openDataOutputStream();
        running = true;
    }

    private void runReader() {
        try {
            while (running) { log("Peer: " + in.readUTF()); }
        } catch (Exception e) { if (running) log("Disconnected."); }
        running = false;
    }

    private void sendMsg(String msg) {
        try { if (out != null) { out.writeUTF(msg); out.flush(); log("Me: " + msg); } }
        catch (Exception e) { log("Send failed"); }
    }

    private void failToMenu(final String reason) {
        display.callSerially(new Runnable() { public void run() {
            Alert a = new Alert("BT Chat", reason, null, AlertType.ERROR);
            display.setCurrent(a, menu);
        }});
    }

    private void closeAll() {
        running = false; closeConn();
        try { if (notifier != null) notifier.close(); } catch (Exception e) {} notifier = null;
    }
    private void closeConn() {
        try { if (in != null) in.close(); } catch (Exception e) {}
        try { if (out != null) out.close(); } catch (Exception e) {}
        try { if (conn != null) conn.close(); } catch (Exception e) {}
        in = null; out = null; conn = null;
    }
}

﻿# J2ME BTChat

Lightweight Bluetooth chat MIDlet for J2ME phones (CLDC 1.1 / MIDP 2.0, JSR-82). Phone-to-phone text chat over RFCOMM/SPP, no SIM/internet required.

## Features
- Host or join a chat over Bluetooth
- Small footprint (~9 KB JAR), simple UI, message log (last 40 lines)
- Networking/IO done in background threads to keep UI responsive
- Data streams (`readUTF`/`writeUTF`) for message framing

## Compatibility
**Not limited to Nokia 7310 Supernova.** Works on J2ME devices that provide:
- **CLDC 1.1** and **MIDP 2.0** (or compatible, e.g. MIDP 2.1)
- **JSR-82** (Bluetooth API, `javax.bluetooth`) with RFCOMM/SPP
- Bluetooth hardware and permissions for `javax.microedition.io.Connector.bluetooth.client/server`

Expected to run on many Nokia S40/S60 and other Java ME phones with Bluetooth/JSR-82. Actual behavior (discoverability, pairing prompts, service discovery) may vary by device/firmware. Requires two devices nearby with Bluetooth enabled; on some phones you may need to pair or set the device visible.

**Not supported:** devices without JSR-82/Bluetooth, or as an internet/Wi-Fi chat (this is local Bluetooth only).

## Install
Copy `dist/BTChat.jar` to the phone and install/open it (on some phones install via `dist/BTChat.jad`). Allow Bluetooth permissions when prompted.

## Usage
1. On device A: **Host (wait)** — waits for a client.
2. On device B: **Join (search)** — select device A, then connect to the `BTChat` service.
3. Use **Send** to exchange messages. **Back** disconnects.

## Build (Windows, Sun/Oracle WTK 2.5.2)
Requires JDK 1.6 (javac/jar) and Sun Java Wireless Toolkit 2.5.2. Adjust paths in `build.bat` if needed, then run:
```bat
build.bat
```
Output: `dist/BTChat.jar` (update `MIDlet-Jar-Size` in `dist/BTChat.jad` to match the built JAR).

## Project layout
- `src/BTChat.java` — MIDlet source
- `dist/BTChat.jar`, `dist/BTChat.jad` — prebuilt binaries
- `MANIFEST.MF` — MIDlet manifest
- `build.bat` — compile/preverify/package script

## Notes
- Keep messages reasonably short; heap on feature phones is limited.
- For phone↔PC chat, a PC-side RFCOMM server using the same service UUID (`F0E0D0C0B0A000908070605040302099`) is required.

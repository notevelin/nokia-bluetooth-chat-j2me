@echo off
if not exist build mkdir build
if not exist dist mkdir dist

echo [1/4] Compiling...
"C:\Program Files (x86)\Java\jdk1.6.0_45\bin\javac.exe" -source 1.3 -target 1.3 -bootclasspath "C:\WTK2.5.2_01\lib\midpapi20.jar;C:\WTK2.5.2_01\lib\cldcapi11.jar;C:\WTK2.5.2_01\lib\jsr082.jar" -d build src\BTChat.java
if %errorlevel% neq 0 exit /b %errorlevel%

echo [2/4] Preverifying...
"C:\WTK2.5.2_01\bin\preverify.exe" -classpath "C:\WTK2.5.2_01\lib\midpapi20.jar;C:\WTK2.5.2_01\lib\cldcapi11.jar;C:\WTK2.5.2_01\lib\jsr082.jar" -d build build
if %errorlevel% neq 0 exit /b %errorlevel%

echo [3/4] Preparing manifest...
if not exist build\META-INF mkdir build\META-INF
copy MANIFEST.MF build\META-INF\MANIFEST.MF /Y

echo [4/4] Creating JAR...
cd build
"C:\Program Files (x86)\Java\jdk1.6.0_45\bin\jar.exe" cfm ..\dist\BTChat.jar META-INF\MANIFEST.MF *.class
cd ..

echo Done: dist\BTChat.jar
